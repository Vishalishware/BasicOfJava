package com.tka.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.tka.dao.IplDao;
import com.tka.entity.Player;

public class IplService {
	IplDao dao = null;
	
	public HashMap<String,ArrayList<Player>> cskAllPlayersService(){
		
			dao = new IplDao();
				
			HashMap<String, ArrayList<Player>> team = dao.cskAllPlayers();
			
			return team;
		
		
	}
	
					ArrayList<Player> cskBatters(){
						
						ArrayList batters = new ArrayList();
						dao = new IplDao();
						
						HashMap<String, ArrayList<Player>> team = dao.cskAllPlayers();
						
						
							return batters;
					}

}
