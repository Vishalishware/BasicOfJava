package com.tka.controller;

import java.util.ArrayList;
import java.util.HashMap;

import com.tka.entity.Player;
import com.tka.service.IplService;

public class IplController {
	IplService service = null;
	
	public HashMap<String,ArrayList<Player>> cskAllPlayersController(){
		
		service = new IplService();
		
		HashMap<String, ArrayList<Player>> team = service.cskAllPlayersService();
		
		return team;
		
	}

}
