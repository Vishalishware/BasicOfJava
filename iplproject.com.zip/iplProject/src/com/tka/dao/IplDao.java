package com.tka.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.tka.entity.Player;

public class IplDao {

	public HashMap<String,ArrayList<Player>> cskAllPlayers(){
		
		HashMap<String,ArrayList<Player>> team = new HashMap<String, ArrayList<Player>>();	
		
		ArrayList<Player> al = new ArrayList<Player>();
		
//		ArrayList<Player> allcskplayers = new ArrayList<Player>();)
			al.add(new Player("Ruturaj",14,3000,0));
			al.add(new Player("Ravindra",8,4000,250));
			al.add(new Player("Shardul",17,1000,300));
			al.add(new Player("Shivam",45,1500,50));
			al.add(new Player("MSD",7,5000,2));
//			
			team.put("CSK", al);
			
		return team;
		
		
	}
}
