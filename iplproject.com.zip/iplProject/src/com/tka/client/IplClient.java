package com.tka.client;

import java.util.ArrayList;
import java.util.HashMap;

import com.tka.controller.IplController;
import com.tka.entity.Player;

public class IplClient {
	public static void main(String[] args) {
		
		IplController controller = new IplController();
		HashMap<String, ArrayList<Player>> cskteam = controller.cskAllPlayersController();
		
		
										controller.cskBatters();
		
//		System.out.println(cskteam.get("CSK"));
		
		ArrayList<Player> arrayList = cskteam.get("CSK");
		
						for(Player p :arrayList) {
							System.out.println(p.getName() + "----> "+  p.getJerseyno());
						}

	}

}
